package com.example.blogpost.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.blogpost.model.Blog;

@Repository
public interface BlogRepositoryService extends JpaRepository<Blog, Integer> {

}
