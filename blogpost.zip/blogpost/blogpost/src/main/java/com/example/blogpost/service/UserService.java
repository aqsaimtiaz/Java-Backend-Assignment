package com.example.blogpost.service;

import com.example.blogpost.model.Author;
import com.example.blogpost.model.UserResponse;

public interface UserService {
	
	public UserResponse getAuthor(String author);

	public UserResponse addAuthor(Author user);
	
}
