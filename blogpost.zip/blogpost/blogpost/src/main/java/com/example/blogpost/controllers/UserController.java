package com.example.blogpost.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.blogpost.model.Author;
import com.example.blogpost.model.UserResponse;
import com.example.blogpost.repository.UserRepositoryService;
import com.example.blogpost.service.UserService;

@RestController
@RequestMapping("/api/author")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @PostMapping("/register")
    public UserResponse register(@RequestBody Author author) {
    	
    	System.out.println(author.toString());
    	final UserResponse userResult =  userService.getAuthor(author.getUsername());
        
    	if(userResult.getResponseCode().contentEquals("00")) {
            return userResult;
        }

        author.setPassword(passwordEncoder.encode(author.getPassword()));
        userService.addAuthor(author);
        return new UserResponse("00", "Success");
    }

    @PostMapping("/login")
    public UserResponse login() {
    	System.out.println("Login Success");
    	 return new UserResponse("00", "Success");
    }
    
   
}
