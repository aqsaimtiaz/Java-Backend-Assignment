package com.example.blogpost.service;

import java.util.List;

import com.example.blogpost.model.Blog;
import com.example.blogpost.model.BlogResponse;

public interface BlogService {

	public List<Blog> getAllBlogs();
	
	public BlogResponse getBlogById(int id);
	
	public BlogResponse editBlogPost(int id, Blog b, String username);
	
	public BlogResponse deleteBlogPost(int id, String username);

	BlogResponse createBlogPost(Blog blog, String username);
		
	
}
