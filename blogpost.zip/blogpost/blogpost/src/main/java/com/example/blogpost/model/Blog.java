package com.example.blogpost.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "blog")
public class Blog  {

	public Blog() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Blog(int id, String header, String post, Author author) {
		super();
		this.id = id;
		this.header = header;
		this.post = post;
		this.author = author;
	}

	@Override
	public String toString() {
		return "Blog [id=" + id + ", header=" + header + ", post=" + post + ", author=" + author + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String header;
	private String post;
	@ManyToOne
	private Author author;
}
