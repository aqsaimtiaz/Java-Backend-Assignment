package com.example.blogpost.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.blogpost.model.Author;
import com.example.blogpost.model.UserResponse;
import com.example.blogpost.repository.UserRepositoryService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserServiceImplementation implements UserService {

	@Autowired
	private UserRepositoryService repositoryService;
	
	
	@Override
	public UserResponse addAuthor(Author user) {
		
		final Author result = this.repositoryService.save(user);
		
		UserResponse b = new UserResponse();
		b.setResponseCode("00");
		b.setResponseDescription("Success");
		b.setUser(result);
		
		return b;
	}

	@Override
	public UserResponse getAuthor(String author) {
		
		final Optional<Author> result = this.repositoryService.findByUsernameIgnoreCase(author);
		
		UserResponse b = new UserResponse();
		
		if(result.isPresent()) {

			b.setResponseCode("00");
			b.setResponseDescription("Success");
			b.setUser(result.get());

		}
		
		b.setResponseCode("012");
		b.setResponseDescription("Failed");

		return b;
	}

}
