package com.example.blogpost.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.blogpost.model.Author;
import com.example.blogpost.model.Blog;
import com.example.blogpost.model.BlogResponse;
import com.example.blogpost.repository.BlogRepositoryService;
import com.example.blogpost.repository.UserRepositoryService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class BlogServiceImplementation implements BlogService {

	@Autowired
	private BlogRepositoryService repositoryService;
	
	@Autowired
	private UserRepositoryService userRepositoryService;
	
	@Override
	public List<Blog> getAllBlogs() {
		
		final List<Blog> result =  this.repositoryService.findAll();
		if(result.size() == 0) {
			
			return new ArrayList<Blog>();
		}
		
		return result;
	}

	@Override
	public BlogResponse getBlogById(int id) {
		
		BlogResponse b = new BlogResponse();
		
		final Optional<Blog> result = this.repositoryService.findById(id);
		if(!result.isPresent()) {
			
			
			b.setResponseCode("01");
			b.setResponseDescription("No Record Found");
			
		}
		
		b.setResponseCode("00");
		b.setResponseDescription("Success");
		b.setBlog(result.get());
		return b;
	}

	@Override
	public BlogResponse createBlogPost(Blog blog, String username) {
		
		BlogResponse response = new BlogResponse();
		
		try {
			final Optional<Author> author = this.userRepositoryService.findByUsernameIgnoreCase(username);
			System.out.println("/create/author" + author.toString());
			
			if(author.isPresent()) {
				
				final Blog result = this.repositoryService.save(blog);
				
				response.setResponseCode("00");
				response.setResponseDescription("Success");
				response.setBlog(result);
			}
			
			
			response.setResponseCode("012");
			response.setResponseDescription("Author Not Found For Post Creation");
			
		} catch (Exception e) {
			
			System.out.println(e.getLocalizedMessage());
			response.setResponseCode("012");
			response.setResponseDescription("Failed");
			
		}
		
		return response;
	}

	@Override
	public BlogResponse editBlogPost(int id, Blog b, String username) {
		
		BlogResponse response = new BlogResponse();
		
		try {
			final Optional<Author> author = this.userRepositoryService.findByUsernameIgnoreCase(username);
			if(author .isPresent() && author.get().getUsername().contentEquals(username)) {
				
				Blog updatedPost = new Blog();
				updatedPost.setHeader(b.getHeader());
				updatedPost.setPost(b.getPost());
				updatedPost.setAuthor(author.get());
				
				final Blog result = this.repositoryService.save(updatedPost);
				
				response.setResponseCode("00");
				response.setResponseDescription("Success");
				response.setBlog(result);
			}
			
			
			response.setResponseCode("012");
			response.setResponseDescription("Author Not Found For Post Creation");
			
		} catch (Exception e) {
			
			response.setResponseCode("012");
			response.setResponseDescription("Failed");
			
		}
		
		return response;
	}

	@Override
	public BlogResponse deleteBlogPost(int id, String username) {
	
		BlogResponse response = new BlogResponse();
		
		try {
			final Optional<Author> author = this.userRepositoryService.findByUsernameIgnoreCase(username);
			if(author.isPresent() && author.get().getUsername().contentEquals(username)) {
				
				
				this.repositoryService.deleteById(id);
				
				response.setResponseCode("00");
				response.setResponseDescription("Success");
			}
			
			
			response.setResponseCode("012");
			response.setResponseDescription("Author Not Found For Post Creation");
			
		} catch (Exception e) {
			
			response.setResponseCode("012");
			response.setResponseDescription("Failed");
			
		}
		
		return response;
	}

}
