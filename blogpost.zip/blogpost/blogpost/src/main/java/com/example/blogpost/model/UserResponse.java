package com.example.blogpost.model;

public class UserResponse {

	public UserResponse(String responseCode, String responseDescription, Author user) {
		super();
		this.responseCode = responseCode;
		this.responseDescription = responseDescription;
		this.user = user;
	}

	public UserResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserResponse(String responseCode, String responseDescription) {
		super();
		this.responseCode = responseCode;
		this.responseDescription = responseDescription;
	}

	@Override
	public String toString() {
		return "UserResponse [responseCode=" + responseCode + ", responseDescription=" + responseDescription + ", user="
				+ user + "]";
	}

	public Author getUser() {
		return user;
	}

	public void setUser(Author user) {
		this.user = user;
	}
	
	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseDescription() {
		return responseDescription;
	}

	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}

	private String responseCode;
	private String responseDescription;
	private Author user;

}
