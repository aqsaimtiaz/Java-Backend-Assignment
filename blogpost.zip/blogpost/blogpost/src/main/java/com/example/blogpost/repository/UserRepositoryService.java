package com.example.blogpost.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.blogpost.model.Author;

@Repository
public interface UserRepositoryService extends JpaRepository<Author, Integer> {

	Optional<Author> findByUsernameIgnoreCase(String username);
}
