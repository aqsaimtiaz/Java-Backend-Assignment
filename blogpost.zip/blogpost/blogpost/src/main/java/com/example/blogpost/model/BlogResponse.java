package com.example.blogpost.model;

public class BlogResponse {

	public BlogResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "BlogResponse [responseCode=" + responseCode + ", responseDescription=" + responseDescription + ", blog="
				+ blog + ", getBlog()=" + getBlog() + ", getResponseCode()=" + getResponseCode()
				+ ", getResponseDescription()=" + getResponseDescription() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	public Blog getBlog() {
		return blog;
	}

	public void setBlog(Blog blog) {
		this.blog = blog;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseDescription() {
		return responseDescription;
	}

	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}

	private String responseCode;
	private String responseDescription;
	private Blog blog;

}
